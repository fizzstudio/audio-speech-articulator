# speech-articulator
 Speech articulation diagram
